from django import forms
from hr_pages import models
from django.forms import widgets

STATUS_CHOICES =(
('draft', 'Draft'),
('open', 'Open'),
('confirm', 'Confirm')
)

class PageForm(forms.ModelForm):

	class Meta:
		model = models.PageModel
		fields = "__all__"
		labels = {
				'name':'Enter Name',	
				}

		widgets = {
			'name': widgets.TextInput(attrs={'placeholder':'Name'}),
			
			}