from django.apps import AppConfig


class HrExpencesConfig(AppConfig):
    name = 'hr_expences'
