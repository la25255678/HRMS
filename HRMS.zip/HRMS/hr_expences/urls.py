from django.urls import path
from hr_expences import views

urlpatterns = [

	path('show_expence/', views.ExpenceListView.as_view(), name='expence_list'),
	path('new_expence/', views.ExpenceCreateView.as_view(), name='expence_create'),
	path('update/<int:pk>/',views.ExpenceUpdateView.as_view(),name='expence_update'),
	path('detail/<int:pk>/', views.ExpenceDetailView.as_view(), name='expence_detail'),
	path('delete/<int:pk>/', views.ExpenceDeleteView.as_view(), name='expence_delete'),
	path('search_by/', views.SearchBy.as_view()),
    path('order_by/', views.OrderBy.as_view())

]