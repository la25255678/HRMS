from django.db import models
from django.utils import timezone

class ExpenceModel(models.Model):
     employees_salary = models.CharField(max_length=20, verbose_name='Employees Salary', default=None)
     office_uses = models.CharField(max_length=20, verbose_name='Office Usue', default=None)
     healthy_sequary = models.CharField(max_length=20, verbose_name='Health And Sequary', default=None)
     other_uses = models.CharField(max_length=20, verbose_name='Other Uses', default=None)
     uses_date = models.DateField(verbose_name='Uses Date', default=timezone.now)
     note = models.TextField(max_length=100, verbose_name='Note') 
     status = models.CharField(max_length=10, verbose_name='Status', default=' ')
     total_expenses = models.CharField(max_length=20, verbose_name='Total Expenses', default=None)
     attachment = models.ImageField(verbose_name='Attachment', default=None, blank=True)

     def __str__(self):
       return self.name