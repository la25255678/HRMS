from django.contrib import admin

# Register your models here.
from hr_expences.models import ExpenceModel
admin.site.register(ExpenceModel)