from django.apps import AppConfig


class HrDepartmentsConfig(AppConfig):
    name = 'hr_departments'
