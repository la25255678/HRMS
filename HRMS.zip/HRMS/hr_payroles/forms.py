from django import forms
from hr_payroles import models
from django.forms import widgets

STATUS_CHOICES =(
('draft', 'Draft'),
('open', 'Open'),
('confirm', 'Confirm')
)

class PayroleForm(forms.ModelForm):

	class Meta:
		model = models.PayroleModel
		fields = "__all__"
		labels = {
				'name':'Enter Name',
				'position':'Enter Position',
				'department':'Enter Department',
				'join_date':'Enter Join Date',
				'basic_salary':'Enter Basic Salary',
				'meal_allowance':'Enter Meal Allowance',
				'travelling_allowance':'Enter Travelling Allowance',
				'total_salary':'Enter Total Salary',
				'daily_wages':'Enter Daily Wages',
				'tax_deduction':'Enter Tax Deduction',
				'other_deduction':'Enter Other Deduction',
				'ot_amt':'Enter OT Amt',
				'next_salary':'Enter Next Salary',
				'attachment':'Upload Attachment'
				}

		widgets = {
			'name': widgets.TextInput(attrs={'placeholder':'Name','class': 'form-control'}),
			'position': widgets.TextInput(attrs={'placeholder':'Position', 'class': 'form-control'}),
			'department': widgets.TextInput(attrs={'placeholder':'Department', 'class': 'form-control'}),
			'join_date': widgets.DateInput(attrs={'placeholder':'Join Date', 'type': 'date', 'class': 'form-control'}),
			'basic_salary': widgets.TextInput(attrs={'placeholder':'Basic Salary', 'class': 'form-control'}),
			'meal_allowance': widgets.TextInput(attrs={'placeholder':'Meal Allowance', 'class': 'form-control'}),
			'travelling_allowance': widgets.TextInput(attrs={'placeholder':'Travelling Allowance', 'class': 'form-control'}),
			'total_salary': widgets.TextInput(attrs={'placeholder':'Total Salary', 'class': 'form-control'}),
			'daily_wages': widgets.TextInput(attrs={'placeholder':'Daily Wages', 'class': 'form-control'}),
			'tax_deduction': widgets.TextInput(attrs={'placeholder':'Tax Deduction', 'class': 'form-control'}),
			'other_deduction': widgets.TextInput(attrs={'placeholder':'Other Deduction', 'class': 'form-control'}),
			'ot_amt': widgets.TextInput(attrs={'placeholder':'OT Amt', 'class': 'form-control'}),
			'next_salary': widgets.TextInput(attrs={'placeholder':'Next Salary', 'class': 'form-control'}),
			'image': widgets.ClearableFileInput()
			}