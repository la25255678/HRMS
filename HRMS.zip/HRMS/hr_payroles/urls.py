from django.urls import path
from hr_payroles import views

urlpatterns = [

	path('show_payrole/', views.PayroleListView.as_view(), name='payrole_list'),
	path('new_payrole/', views.PayroleCreateView.as_view(), name='payrole_create'),
	path('update/<int:pk>/', views.PayroleUpdateView.as_view(), name='payrole_update'),
	path('detail/<int:pk>/', views.PayroleDetailView.as_view(), name='payrole_detail'),
	path('delete/<int:pk>/', views.PayroleDeleteView.as_view(), name='payrole_delete'),
	path('search_by/', views.SearchBy.as_view()),
    path('order_by/', views.OrderBy.as_view()),



]