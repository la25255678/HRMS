from django.apps import AppConfig


class HrPayrolesConfig(AppConfig):
    name = 'hr_payroles'
